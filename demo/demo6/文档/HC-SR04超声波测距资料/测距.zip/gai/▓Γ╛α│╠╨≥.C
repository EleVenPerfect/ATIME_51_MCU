#include   <reg52.H>
#include	"cejv.h"



/********************************************************/
void main(void)
{  
		cj_init();
		while(1)
		{
			 cj_run();
			 delayms(100);		//100MS
		}
}              